SkiaSharp is a cross-platform 2D graphics API for .NET platforms based on Google's Skia Graphics Library.
It provides a comprehensive 2D API that can be used across mobile, server and desktop models to render images.
