document.getElementById('submitButton').addEventListener('click', function() {
    alert('Claim submitted!');
});