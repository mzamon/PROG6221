using System;

namespace CSharpProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, C# Project!");
        }
    }
} 