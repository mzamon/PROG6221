# Design Documentation

## Design Choices
- Explanation of design choices for the Contract Monthly Claim System (CMCS).

## Database Structure
- Description of the database structure and its components.

## GUI Layout
- Overview of the GUI layout and its elements.

## Assumptions and Constraints
- List of assumptions and constraints considered during the design process.