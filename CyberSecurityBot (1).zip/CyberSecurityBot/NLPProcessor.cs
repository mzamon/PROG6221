using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace CyberSecurityChatbot
{
    public class NLPProcessor
    {
        private readonly Dictionary<string, List<string>> _intentPatterns;
        private readonly Dictionary<string, string[]> _responses;
        private readonly Random _random = new Random();

        public NLPProcessor()
        {
            InitializePatterns();
            InitializeResponses();
        }

        private void InitializePatterns()
        {
            _intentPatterns = new Dictionary<string, List<string>>
            {
                ["greeting"] = new List<string>
                {
                    @"^(hi|hello|hey|greetings|howdy)(\s|$)",
                    @"^good\s(morning|afternoon|evening)(\s|$)"
                },
                ["farewell"] = new List<string>
                {
                    @"^(bye|goodbye|see\syou|farewell)(\s|$)",
                    @"^(exit|quit|close)(\s|$)"
                },
                ["help"] = new List<string>
                {
                    @"(help|assist|support)(\s|$)",
                    @"^what\scan\syou\sdo",
                    @"^how\sdo\syou\swork",
                    @"^show\scommands"
                },
                ["thanks"] = new List<string>
                {
                    @"(thank|thanks|appreciate|grateful)"
                },
                ["password_help"] = new List<string>
                {
                    @"(password|passwords)",
                    @"(secure\spassword|strong\spassword)",
                    @"how\sto\screate(\sa)?\spassword"
                },
                ["phishing"] = new List<string>
                {
                    @"(phishing|scam\semail|fake\semail)",
                    @"(identify|spot|detect)\s(phishing|scam)",
                    @"suspicious\s(email|link|message)"
                },
                ["malware"] = new List<string>
                {
                    @"(malware|virus|trojan|ransomware|spyware)",
                    @"(protect|remove|detect)\s(malware|virus)"
                },
                ["add_task"] = new List<string>
                {
                    @"(add|create|new)\s(task|reminder)",
                    @"remind\sme\sto"
                },
                ["view_tasks"] = new List<string>
                {
                    @"(show|view|list|display)\s(task|tasks|reminder|reminders)",
                    @"what\s(task|tasks|reminder|reminders)"
                },
                ["delete_task"] = new List<string>
                {
                    @"(delete|remove|clear)\s(task|reminder)"
                },
                ["complete_task"] = new List<string>
                {
                    @"(complete|finish|mark\sdone|check\soff)\s(task|reminder)"
                },
                ["two_factor"] = new List<string>
                {
                    @"(two\sfactor|2fa|multi\sfactor|mfa)",
                    @"(enable|setup|configure)\s(authentication|2fa)"
                },
                ["vpn"] = new List<string>
                {
                    @"(vpn|virtual\sprivate\snetwork)",
                    @"(secure|encrypted)\sconnection"
                },
                ["encryption"] = new List<string>
                {
                    @"(encrypt|encryption|cryptography)",
                    @"(protect|secure)\s(data|information|files)"
                },
                ["updates"] = new List<string>
                {
                    @"(update|upgrade|patch)",
                    @"(software|system)\s(update|upgrade)",
                    @"(keep|maintain)\s(software|system)\sup\sto\sdate"
                },
                ["backup"] = new List<string>
                {
                    @"(backup|back\sup|back-up)",
                    @"(save|store|preserve)\s(data|files|information)"
                },
                ["firewall"] = new List<string>
                {
                    @"(firewall|network\sprotection)",
                    @"(block|filter|control)\s(traffic|connection)"
                },
                ["start_quiz"] = new List<string>
                {
                    @"(start|begin|take)\s(quiz|test|assessment)",
                    @"(quiz|test)\sme"
                }
            };
        }

        private void InitializeResponses()
        {
            _responses = new Dictionary<string, string[]>
            {
                ["greeting"] = new[]
                {
                    "Hello! I'm CyberBot, your cybersecurity assistant. How can I help protect your digital life today?",
                    "Hi there! I'm CyberBot. Ask me anything about cybersecurity best practices!",
                    "Greetings! CyberBot at your service. What cybersecurity topic would you like to explore?"
                },
                ["farewell"] = new[]
                {
                    "Goodbye! Stay secure online!",
                    "Farewell! Remember to keep your software updated and passwords strong.",
                    "Until next time! Don't forget to backup your important data."
                },
                ["help"] = new[]
                {
                    "I can help with various cybersecurity topics like password management, phishing awareness, and malware protection. I can also manage security tasks and offer a quiz to test your knowledge.\n\nSome example commands:\n- Tell me about strong passwords\n- How to identify phishing\n- Add a security task\n- Start a cybersecurity quiz",
                    "I'm CyberBot, your cybersecurity assistant. You can ask me about:\n- Password security\n- Phishing detection\n- Malware protection\n- Two-factor authentication\n- VPNs and encryption\nI can also manage your security tasks and offer knowledge quizzes."
                },
                ["thanks"] = new[]
                {
                    "You're welcome! Cybersecurity is a team effort.",
                    "Happy to help keep you secure online!",
                    "No problem! Staying informed is the first step to staying secure."
                },
                ["password_help"] = new[]
                {
                    "Strong passwords should be long (at least 12 characters), use a mix of uppercase, lowercase, numbers and symbols, and be unique for each account. Consider using a password manager to create and store complex passwords securely.",
                    "For better password security: 1) Use passphrases instead of single words, 2) Never reuse passwords across accounts, 3) Enable two-factor authentication when available, 4) Consider using a reputable password manager.",
                    "To create strong passwords, avoid using personal information, dictionary words, or common patterns. Use a unique password for each account and change critical passwords regularly. Password managers can help generate and store secure passwords."
                },
                ["phishing"] = new[]
                {
                    "To identify phishing attempts, look for: unexpected emails requesting urgent action, mismatched or suspicious URLs, poor grammar/spelling, generic greetings, and requests for sensitive information. Always verify requests through official channels before responding.",
                    "Common signs of phishing include: suspicious sender email addresses, unexpected attachments/links, threats or urgency, requests for personal information, and offers that seem too good to be true. Hover over links (don't click) to preview actual URLs.",
                    "To avoid phishing scams: 1) Don't click on suspicious links, 2) Be wary of unexpected emails even if they appear to be from known senders, 3) Check the actual email address, not just the display name, 4) Never provide sensitive information via email."
                },
                ["malware"] = new[]
                {
                    "To protect against malware: 1) Keep your software updated, 2) Use reputable antivirus software, 3) Be careful what you download, 4) Don't click suspicious links or open unknown attachments, 5) Use strong passwords and enable two-factor authentication.",
                    "Signs your device might be infected with malware include: unusual slowness, unexpected pop-ups, changes to your homepage, unexplained data usage, battery draining quickly, or strange charges on your accounts.",
                    "If you suspect malware infection: 1) Disconnect from the internet, 2) Run a full scan with updated antivirus software, 3) Remove detected threats, 4) Update all software, 5) Reset passwords from a clean device if necessary."
                },
                ["two_factor"] = new[]
                {
                    "Two-factor authentication (2FA) adds an extra layer of security by requiring something you know (password) and something you have (like your phone). Enable it on all accounts that offer it, especially email, financial, and social media accounts.",
                    "For 2FA, app-based authenticators (like Google Authenticator or Authy) are generally more secure than SMS-based methods, as text messages can be intercepted. For critical accounts, consider using hardware security keys for maximum protection.",
                    "To set up 2FA: 1) Go to your account security settings, 2) Look for two-factor or two-step verification options, 3) Choose your preferred method (app, SMS, security key), 4) Follow the setup instructions, 5) Save backup codes in a secure location."
                },
                ["vpn"] = new[]
                {
                    "A Virtual Private Network (VPN) encrypts your internet connection, helping protect your data when using public Wi-Fi. It can also mask your IP address and location. However, not all VPNs are equal—research providers before choosing one.",
                    "When selecting a VPN service, look for: no-logs policies (verified by independent audits), strong encryption standards, kill switch features, and transparency about business practices. Avoid free VPNs that might sell your data.",
                    "Use a VPN when: connecting to public Wi-Fi, accessing sensitive information online, or when privacy is a concern. However, remember that a VPN is just one tool in your security toolkit—it doesn't make you completely anonymous."
                },
                ["encryption"] = new[]
                {
                    "Encryption converts your data into a code to prevent unauthorized access. For personal use, enable full-disk encryption on your devices (BitLocker on Windows, FileVault on Mac), and use encrypted messaging apps like Signal for sensitive communications.",
                    "To protect sensitive files: 1) Use encryption software like VeraCrypt to create encrypted containers, 2) Enable HTTPS everywhere when browsing, 3) Use end-to-end encrypted email when necessary, 4) Encrypt your backups.",
                    "End-to-end encryption means only the communicating users can read the messages. It's essential for sensitive communications. Apps like Signal, WhatsApp, and ProtonMail offer this protection, keeping your messages private even from the service providers."
                },
                ["updates"] = new[]
                {
                    "Software updates often contain critical security patches. Set your operating system and applications to update automatically when possible. Outdated software is one of the most common entry points for malware.",
                    "For effective update management: 1) Enable automatic updates when available, 2) Regularly check for updates that require manual installation, 3) Don't postpone critical security updates, 4) Consider retiring software that's no longer supported.",
                    "When a major update is available, back up your important data first. Install updates during periods when you don't need immediate access to your device, as some updates require system restarts and might take time to complete."
                },
                ["backup"] = new[]
                {
                    "Follow the 3-2-1 backup rule: keep 3 copies of important data, on 2 different media types, with 1 copy stored off-site or in the cloud. Regularly test your backups to ensure you can actually restore from them when needed.",
                    "For effective backups: 1) Automate the process so it happens regularly, 2) Encrypt sensitive backup data, 3) Keep some backups offline to protect against ransomware, 4) Document your backup and recovery procedures.",
                    "Cloud backups are convenient but consider privacy implications. Use services that offer zero-knowledge encryption where possible, meaning the provider cannot access your data. Always enable two-factor authentication on cloud storage accounts."
                },
                ["firewall"] = new[]
                {
                    "A firewall acts as a barrier between your network and the internet, monitoring and controlling incoming and outgoing traffic. Ensure your device's built-in firewall is activated, and consider a hardware firewall for home networks with multiple devices.",
                    "Modern operating systems include built-in firewalls. To check if yours is active: on Windows, search for 'Windows Security' then 'Firewall & network protection'; on Mac, go to System Preferences > Security & Privacy > Firewall.",
                    "For advanced protection, consider configuring your firewall to use application-based rules rather than just port-based ones. This gives you more granular control over which programs can access the network and how they can communicate."
                },
                ["unknown"] = new[]
                {
                    "I'm not sure I understand. Could you rephrase your question about cybersecurity?",
                    "I didn't quite catch that. I'm focused on cybersecurity topics like passwords, phishing, malware, and general online safety. How can I help with those areas?",
                    "I'm specialized in cybersecurity topics. Could you clarify what security-related information you're looking for?"
                }
            };
        }

        public (string intent, string response) ProcessInput(string userInput)
        {
            if (string.IsNullOrWhiteSpace(userInput))
            {
                return ("unknown", GetRandomResponse("unknown"));
            }

            string normalizedInput = userInput.ToLower().Trim();
            
            foreach (var intentPattern in _intentPatterns)
            {
                string intent = intentPattern.Key;
                
                foreach (string pattern in intentPattern.Value)
                {
                    if (Regex.IsMatch(normalizedInput, pattern, RegexOptions.IgnoreCase))
                    {
                        return (intent, GetRandomResponse(intent));
                    }
                }
            }

            return ("unknown", GetRandomResponse("unknown"));
        }

        private string GetRandomResponse(string intent)
        {
            if (_responses.TryGetValue(intent, out string[] possibleResponses))
            {
                return possibleResponses[_random.Next(possibleResponses.Length)];
            }
            return _responses["unknown"][0];
        }

        public bool IsAddTaskIntent(string intent)
        {
            return intent == "add_task";
        }

        public bool IsViewTasksIntent(string intent)
        {
            return intent == "view_tasks";
        }

        public bool IsDeleteTaskIntent(string intent)
        {
            return intent == "delete_task";
        }

        public bool IsCompleteTaskIntent(string intent)
        {
            return intent == "complete_task";
        }

        public bool IsStartQuizIntent(string intent)
        {
            return intent == "start_quiz";
        }

        public (string title, string description, DateTime? reminderDate) ExtractTaskInfo(string userInput)
        {
            string title = "New Security Task";
            string description = userInput;
            DateTime? reminderDate = null;

            // Try to extract a potential title (first sentence or segment)
            var titleMatch = Regex.Match(userInput, @"^[^\.,:;]+");
            if (titleMatch.Success && titleMatch.Value.Length > 5 && titleMatch.Value.Length < 50)
            {
                title = titleMatch.Value.Trim();
                // Remove the title from the description if it was extracted
                description = userInput.Substring(title.Length).Trim(' ', ',', ':', ';', '.');
                if (string.IsNullOrWhiteSpace(description))
                {
                    description = title;
                }
            }

            // Look for date references
            var dateMatches = new[]
            {
                // tomorrow
                Regex.Match(userInput, @"tomorrow", RegexOptions.IgnoreCase),
                // next week
                Regex.Match(userInput, @"next\s+week", RegexOptions.IgnoreCase),
                // in X days
                Regex.Match(userInput, @"in\s+(\d+)\s+days?", RegexOptions.IgnoreCase),
                // on Monday, Tuesday, etc.
                Regex.Match(userInput, @"on\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)", RegexOptions.IgnoreCase),
                // specific date formats
                Regex.Match(userInput, @"(\d{1,2})[\/\.-](\d{1,2})[\/\.-](\d{2,4})", RegexOptions.IgnoreCase)
            };

            foreach (var match in dateMatches)
            {
                if (match.Success)
                {
                    if (match.Value.Contains("tomorrow"))
                    {
                        reminderDate = DateTime.Today.AddDays(1);
                    }
                    else if (match.Value.Contains("next week"))
                    {
                        reminderDate = DateTime.Today.AddDays(7);
                    }
                    else if (match.Value.StartsWith("in "))
                    {
                        var daysMatch = Regex.Match(match.Value, @"(\d+)");
                        if (daysMatch.Success && int.TryParse(daysMatch.Groups[1].Value, out int days))
                        {
                            reminderDate = DateTime.Today.AddDays(days);
                        }
                    }
                    else if (match.Value.StartsWith("on "))
                    {
                        var dayMatch = Regex.Match(match.Value, @"(monday|tuesday|wednesday|thursday|friday|saturday|sunday)", RegexOptions.IgnoreCase);
                        if (dayMatch.Success)
                        {
                            string dayName = dayMatch.Groups[1].Value.ToLower();
                            DayOfWeek targetDay = Enum.Parse<DayOfWeek>(char.ToUpper(dayName[0]) + dayName.Substring(1));
                            
                            int daysUntilTarget = ((int)targetDay - (int)DateTime.Today.DayOfWeek + 7) % 7;
                            if (daysUntilTarget == 0) // If today is the target day, move to next week
                            {
                                daysUntilTarget = 7;
                            }
                            
                            reminderDate = DateTime.Today.AddDays(daysUntilTarget);
                        }
                    }
                    else
                    {
                        // Try to parse specific date formats
                        var parts = match.Value.Split(new[] { '/', '.', '-' });
                        if (parts.Length == 3)
                        {
                            if (int.TryParse(parts[0], out int month) && 
                                int.TryParse(parts[1], out int day) && 
                                int.TryParse(parts[2], out int year))
                            {
                                if (year < 100)
                                {
                                    year += 2000; // Assume 20xx for two-digit years
                                }
                                
                                try
                                {
                                    reminderDate = new DateTime(year, month, day);
                                }
                                catch
                                {
                                    // Invalid date, ignore
                                }
                            }
                        }
                    }

                    break;
                }
            }

            return (title, description, reminderDate);
        }
    }
}