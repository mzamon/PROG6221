using System;
using System.Collections.Generic;
using System.Linq;

namespace CyberSecurityChatbot
{
    public class QuizQuestion
    {
        public string Question { get; set; }
        public string[] Options { get; set; }
        public int CorrectAnswerIndex { get; set; }
        public string Explanation { get; set; }

        public QuizQuestion(string question, string[] options, int correctAnswerIndex, string explanation)
        {
            Question = question;
            Options = options;
            CorrectAnswerIndex = correctAnswerIndex;
            Explanation = explanation;
        }
    }

    public class QuizManager
    {
        private readonly List<QuizQuestion> _questions;
        private readonly Random _random = new Random();
        private int _currentScore;
        private int _currentQuestionIndex;
        private List<QuizQuestion> _currentQuizQuestions;

        public int CurrentQuestionIndex => _currentQuestionIndex;
        public int TotalQuestions => _currentQuizQuestions?.Count ?? 0;
        public int CurrentScore => _currentScore;

        public QuizManager()
        {
            _questions = InitializeQuestions();
            _currentScore = 0;
            _currentQuestionIndex = 0;
            _currentQuizQuestions = new List<QuizQuestion>();
        }

        private List<QuizQuestion> InitializeQuestions()
        {
            return new List<QuizQuestion>
            {
                new QuizQuestion(
                    "What is a strong password typically characterized by?",
                    new[] {
                        "A word found in the dictionary",
                        "Your pet's name with your birth year",
                        "A mix of uppercase, lowercase, numbers, and symbols",
                        "The same password used across all accounts"
                    },
                    2,
                    "Strong passwords use a combination of character types, are at least 12 characters long, and are unique for each service."
                ),
                new QuizQuestion(
                    "Which of the following is a common sign of a phishing attempt?",
                    new[] {
                        "The email comes from someone in your contact list",
                        "The email has poor grammar and spelling mistakes",
                        "The email was received during business hours",
                        "The email doesn't ask for any personal information"
                    },
                    1,
                    "Phishing emails often contain poor grammar, spelling mistakes, and unprofessional formatting."
                ),
                new QuizQuestion(
                    "What does two-factor authentication (2FA) require?",
                    new[] {
                        "Two different passwords",
                        "Two different usernames",
                        "Something you know and something you have",
                        "Biometric verification only"
                    },
                    2,
                    "2FA typically requires something you know (password) and something you have (like a phone to receive codes)."
                ),
                new QuizQuestion(
                    "Which practice helps protect against ransomware?",
                    new[] {
                        "Opening email attachments from unknown senders",
                        "Regularly backing up important data",
                        "Disabling your firewall",
                        "Postponing software updates"
                    },
                    1,
                    "Regular backups ensure you can recover your data without paying ransom if your files are encrypted by ransomware."
                ),
                new QuizQuestion(
                    "What is a VPN primarily used for?",
                    new[] {
                        "Speeding up your internet connection",
                        "Backing up your data automatically",
                        "Encrypting your internet traffic",
                        "Blocking all advertisements"
                    },
                    2,
                    "VPNs create an encrypted tunnel for your internet traffic, helping protect your data especially on public Wi-Fi."
                ),
                new QuizQuestion(
                    "Which of the following is NOT a good security practice?",
                    new[] {
                        "Using a password manager",
                        "Writing down passwords on sticky notes",
                        "Enabling automatic software updates",
                        "Using different passwords for different accounts"
                    },
                    1,
                    "Writing down passwords makes them physically vulnerable to theft or unauthorized access."
                ),
                new QuizQuestion(
                    "What type of malware demands payment to unlock your files?",
                    new[] {
                        "Spyware",
                        "Adware",
                        "Trojan",
                        "Ransomware"
                    },
                    3,
                    "Ransomware encrypts your files and demands payment (usually in cryptocurrency) for the decryption key."
                ),
                new QuizQuestion(
                    "Which of these is a secure messaging practice?",
                    new[] {
                        "Sending sensitive information via regular SMS",
                        "Using messaging apps with end-to-end encryption",
                        "Sharing passwords through direct messages",
                        "Clicking on links without verifying their authenticity"
                    },
                    1,
                    "End-to-end encryption ensures only the communicating users can read the messages, not even the service provider."
                ),
                new QuizQuestion(
                    "What should you do before downloading software?",
                    new[] {
                        "Disable your antivirus temporarily",
                        "Verify the source is legitimate and trusted",
                        "Share the download link with friends first",
                        "Make sure it's a large file (more features)"
                    },
                    1,
                    "Only download software from official websites or trusted sources to avoid malware."
                ),
                new QuizQuestion(
                    "Which statement about public Wi-Fi is most accurate?",
                    new[] {
                        "It's generally as secure as your home network",
                        "It's safe as long as the network has a password",
                        "It's best to avoid accessing sensitive accounts on public Wi-Fi",
                        "The busier the location, the more secure the Wi-Fi"
                    },
                    2,
                    "Public Wi-Fi networks, even password-protected ones, can be monitored or spoofed. Avoid accessing sensitive information unless using a VPN."
                ),
                new QuizQuestion(
                    "What is social engineering in cybersecurity?",
                    new[] {
                        "Using social media to promote security awareness",
                        "Psychological manipulation to trick people into revealing information",
                        "Building secure social networking platforms",
                        "The practice of securing social media accounts"
                    },
                    1,
                    "Social engineering attacks exploit human psychology rather than technical hacking techniques to gain access to buildings, systems or data."
                ),
                new QuizQuestion(
                    "Which of the following is a secure way to dispose of an old computer?",
                    new[] {
                        "Delete all files and empty the recycle bin",
                        "Physically destroy or professionally wipe the hard drive",
                        "Reset to factory settings",
                        "Remove the battery before disposing"
                    },
                    1,
                    "Standard deletion doesn't truly remove data. Physical destruction or professional data wiping ensures your personal information cannot be recovered."
                ),
                new QuizQuestion(
                    "What is a software patch primarily designed to do?",
                    new[] {
                        "Add new features to the software",
                        "Make the software run faster",
                        "Fix security vulnerabilities and bugs",
                        "Change the user interface"
                    },
                    2,
                    "While patches may include new features, their primary purpose is fixing known security vulnerabilities and bugs."
                ),
                new QuizQuestion(
                    "Which password is strongest?",
                    new[] {
                        "Password123!",
                        "January2023",
                        "qwerty12345",
                        "P4k!m9Vr$2zL"
                    },
                    3,
                    "Strong passwords are long, random combinations of uppercase, lowercase, numbers and special characters without patterns or dictionary words."
                ),
                new QuizQuestion(
                    "What is the best practice when you receive an email asking you to update your payment information?",
                    new[] {
                        "Click the link in the email if it looks legitimate",
                        "Call the sender to verify first",
                        "Go directly to the official website by typing the URL",
                        "Reply to the email asking for verification"
                    },
                    2,
                    "Never click links in emails requesting sensitive information. Instead, go directly to the official website by typing the URL in your browser."
                )
            };
        }

        public void StartNewQuiz(int numberOfQuestions = 5)
        {
            _currentScore = 0;
            _currentQuestionIndex = 0;
            
            // Select random questions
            _currentQuizQuestions = _questions
                .OrderBy(q => _random.Next())
                .Take(Math.Min(numberOfQuestions, _questions.Count))
                .ToList();
        }

        public QuizQuestion GetCurrentQuestion()
        {
            if (_currentQuizQuestions == null || _currentQuestionIndex >= _currentQuizQuestions.Count)
            {
                return null;
            }
            
            return _currentQuizQuestions[_currentQuestionIndex];
        }

        public bool AnswerQuestion(int selectedOptionIndex)
        {
            var currentQuestion = GetCurrentQuestion();
            if (currentQuestion == null)
            {
                return false;
            }
            
            bool isCorrect = selectedOptionIndex == currentQuestion.CorrectAnswerIndex;
            if (isCorrect)
            {
                _currentScore++;
            }
            
            _currentQuestionIndex++;
            return isCorrect;
        }

        public bool IsQuizComplete()
        {
            return _currentQuizQuestions != null && 
                   _currentQuestionIndex >= _currentQuizQuestions.Count;
        }

        public string GetFeedback()
        {
            if (_currentQuizQuestions == null || _currentQuizQuestions.Count == 0)
            {
                return "No quiz in progress.";
            }
            
            double percentage = (double)_currentScore / _currentQuizQuestions.Count * 100;
            
            if (percentage >= 90)
            {
                return "Excellent! You're a cybersecurity expert!";
            }
            else if (percentage >= 70)
            {
                return "Good job! You have a solid understanding of cybersecurity concepts.";
            }
            else if (percentage >= 50)
            {
                return "Not bad! You have basic cybersecurity knowledge but there's room for improvement.";
            }
            else
            {
                return "You might want to review cybersecurity basics. Keep learning!";
            }
        }
    }
}