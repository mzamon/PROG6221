using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace CyberSecurityChatbot
{
    public partial class MainWindow : Window
    {
        private readonly NLPProcessor _nlpProcessor;
        private readonly ActivityLogger _activityLogger;
        private readonly TaskManager _taskManager;
        private readonly QuizManager _quizManager;
        private bool _isQuizMode = false;
        private bool _isTaskMode = false;
        private string _currentTaskAction = "";
        private readonly DispatcherTimer _reminderTimer;

        public MainWindow()
        {
            try
            {
                InitializeComponent();
                
                _nlpProcessor = new NLPProcessor();
                _activityLogger = new ActivityLogger();
                _taskManager = new TaskManager();
                _quizManager = new QuizManager();
                
                // Display ASCII art and welcome message
                DisplayWelcomeMessage();
                
                // Initialize reminder timer
                _reminderTimer = new DispatcherTimer
                {
                    Interval = TimeSpan.FromMinutes(5)
                };
                _reminderTimer.Tick += ReminderTimer_Tick;
                _reminderTimer.Start();
                
                // Update UI with tasks and logs
                UpdateTaskList();
                UpdateActivityLog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error initializing application: {ex.Message}", "Initialization Error", 
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DisplayWelcomeMessage()
        {
            try
            {
                string asciiArt = LoadAsciiArt();
                
                string welcomeMessage = $"{asciiArt}\n\n" +
                    "Welcome to CyberSecurityBot!\n" +
                    "I'm your assistant for cybersecurity best practices, tips, and reminders.\n" +
                    "How can I help you today?\n\n" +
                    "You can ask me about:\n" +
                    "- Password security\n" +
                    "- Phishing detection\n" +
                    "- Malware protection\n" +
                    "- Two-factor authentication\n" +
                    "- Or type 'help' for more options";
                
                AddBotMessage(welcomeMessage);
                _activityLogger.AddEntry("CyberSecurityBot started.");
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Failed to display welcome message: {ex.Message}");
            }
        }

        private string LoadAsciiArt()
        {
            try
            {
                // Try to load the ASCII art from embedded resource
                using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("CyberSecurityChatbot.Resources.cyber_shield.txt"))
                {
                    if (stream != null)
                    {
                        using (StreamReader reader = new StreamReader(stream))
                        {
                            return reader.ReadToEnd();
                        }
                    }
                }

                // Fallback ASCII art if resource loading fails
                return @"    /\     /\     
   /  \___/  \    
  /           \   
 /  CYBERBOT  \  
/___/\___/\___\ 
    /  \   \    
   /    \   \   
  /      \   \  
 /        \   \ 
/          \___\";
            }
            catch
            {
                // Default minimal ASCII art as fallback
                return "==== CyberSecurityBot ====";
            }
        }

        private void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                SendButton_Click(sender, e);
                e.Handled = true;
            }
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string userInput = InputBox.Text.Trim();
                if (string.IsNullOrEmpty(userInput))
                    return;

                AddUserMessage(userInput);
                InputBox.Text = string.Empty;

                ProcessUserInput(userInput);
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error processing input: {ex.Message}");
                AddBotMessage("Sorry, I encountered an error processing your request. Please try again.");
            }
        }

        private void ProcessUserInput(string input)
        {
            try
            {
                if (_isQuizMode)
                {
                    ProcessQuizInput(input);
                    return;
                }

                if (_isTaskMode)
                {
                    ProcessTaskInput(input);
                    return;
                }

                // Normal chat mode
                var (intent, response) = _nlpProcessor.ProcessInput(input);

                if (_nlpProcessor.IsStartQuizIntent(intent))
                {
                    StartQuiz();
                }
                else if (_nlpProcessor.IsAddTaskIntent(intent))
                {
                    StartAddTask(input);
                }
                else if (_nlpProcessor.IsViewTasksIntent(intent))
                {
                    ShowTaskList();
                }
                else if (_nlpProcessor.IsDeleteTaskIntent(intent))
                {
                    StartDeleteTask();
                }
                else if (_nlpProcessor.IsCompleteTaskIntent(intent))
                {
                    StartCompleteTask();
                }
                else
                {
                    AddBotMessage(response);
                }
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error in ProcessUserInput: {ex.Message}");
                AddBotMessage("I'm sorry, but I encountered an issue processing your request. Could you try again?");
            }
        }

        #region Quiz Mode

        private void StartQuiz()
        {
            try
            {
                _isQuizMode = true;
                _quizManager.StartNewQuiz(5); // 5 questions per quiz
                _activityLogger.LogQuizStarted();
                
                AddBotMessage("Welcome to the Cybersecurity Quiz! I'll ask you 5 questions about cybersecurity best practices. Let's see how you do!");
                
                DisplayCurrentQuestion();
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Failed to start quiz: {ex.Message}");
                _isQuizMode = false;
                AddBotMessage("Sorry, I couldn't start the quiz. Please try again later.");
            }
        }

        private void ProcessQuizInput(string input)
        {
            try
            {
                if (int.TryParse(input, out int answerIndex) && answerIndex >= 1 && answerIndex <= 4)
                {
                    // Adjust to 0-based index
                    bool isCorrect = _quizManager.AnswerQuestion(answerIndex - 1);
                    
                    var currentQuestion = _quizManager.GetCurrentQuestion();
                    string explanation = currentQuestion != null ? currentQuestion.Explanation : "";
                    
                    if (isCorrect)
                    {
                        AddBotMessage("✓ Correct! " + explanation);
                    }
                    else
                    {
                        int correctOption = currentQuestion.CorrectAnswerIndex + 1;
                        AddBotMessage($"✗ Incorrect. The correct answer was {correctOption}. " + explanation);
                    }
                    
                    if (_quizManager.IsQuizComplete())
                    {
                        EndQuiz();
                    }
                    else
                    {
                        DisplayCurrentQuestion();
                    }
                }
                else
                {
                    AddBotMessage("Please enter a number between 1 and 4 to select your answer.");
                }
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error processing quiz input: {ex.Message}");
                AddBotMessage("Sorry, there was an error processing your answer. Let's try the next question.");
                
                if (!_quizManager.IsQuizComplete())
                {
                    _quizManager.AnswerQuestion(0); // Skip to next question
                    DisplayCurrentQuestion();
                }
                else
                {
                    EndQuiz();
                }
            }
        }

        private void DisplayCurrentQuestion()
        {
            try
            {
                var question = _quizManager.GetCurrentQuestion();
                if (question == null)
                {
                    EndQuiz();
                    return;
                }
                
                int questionNumber = _quizManager.CurrentQuestionIndex + 1;
                int totalQuestions = _quizManager.TotalQuestions;
                
                StringBuilder sb = new StringBuilder();
                sb.AppendLine($"Question {questionNumber} of {totalQuestions}:");
                sb.AppendLine(question.Question);
                sb.AppendLine();
                
                for (int i = 0; i < question.Options.Length; i++)
                {
                    sb.AppendLine($"{i + 1}. {question.Options[i]}");
                }
                
                sb.AppendLine("\nEnter the number of your answer (1-4):");
                AddBotMessage(sb.ToString());
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error displaying quiz question: {ex.Message}");
                AddBotMessage("Sorry, I couldn't display the current question. Let's end the quiz.");
                EndQuiz();
            }
        }

        private void EndQuiz()
        {
            try
            {
                _isQuizMode = false;
                int score = _quizManager.CurrentScore;
                int total = _quizManager.TotalQuestions;
                double percentage = (double)score / total * 100;
                
                StringBuilder sb = new StringBuilder();
                sb.AppendLine($"Quiz completed! Your score: {score}/{total} ({percentage:F0}%)");
                sb.AppendLine();
                sb.AppendLine(_quizManager.GetFeedback());
                sb.AppendLine();
                sb.AppendLine("Would you like to learn more about any cybersecurity topic? Just ask!");
                
                AddBotMessage(sb.ToString());
                _activityLogger.LogQuizCompleted(score, total);
                UpdateActivityLog();
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error ending quiz: {ex.Message}");
                _isQuizMode = false;
                AddBotMessage("The quiz has ended. I encountered an issue calculating your score. Feel free to ask me about cybersecurity topics!");
            }
        }

        #endregion

        #region Task Management

        private void StartAddTask(string userInput)
        {
            try
            {
                var (title, description, reminderDate) = _nlpProcessor.ExtractTaskInfo(userInput);
                
                if (string.IsNullOrEmpty(title))
                {
                    _isTaskMode = true;
                    _currentTaskAction = "add";
                    AddBotMessage("What task would you like me to add to your security checklist?");
                }
                else
                {
                    _taskManager.AddTask(title, description, reminderDate);
                    _activityLogger.LogTaskAdded(title);
                    
                    AddBotMessage($"I've added the task: '{title}' to your security checklist.");
                    if (reminderDate.HasValue)
                    {
                        AddBotMessage($"I'll remind you about this on {reminderDate.Value.ToString("MMM dd, yyyy")}.");
                        _activityLogger.LogReminderSet(title, reminderDate.Value);
                    }
                    
                    UpdateTaskList();
                    UpdateActivityLog();
                }
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error adding task: {ex.Message}");
                AddBotMessage("I couldn't add that task. Please try again with a clearer description.");
                _isTaskMode = false;
            }
        }

        private void ProcessTaskInput(string input)
        {
            try
            {
                switch (_currentTaskAction)
                {
                    case "add":
                        var (title, description, reminderDate) = _nlpProcessor.ExtractTaskInfo(input);
                        _taskManager.AddTask(title, description, reminderDate);
                        _activityLogger.LogTaskAdded(title);
                        
                        AddBotMessage($"Task added: '{title}'");
                        if (reminderDate.HasValue)
                        {
                            AddBotMessage($"I'll remind you about this on {reminderDate.Value.ToString("MMM dd, yyyy")}.");
                            _activityLogger.LogReminderSet(title, reminderDate.Value);
                        }
                        break;
                        
                    case "delete":
                        if (int.TryParse(input, out int deleteIndex) && deleteIndex > 0 && deleteIndex <= _taskManager.Tasks.Count)
                        {
                            var taskToDelete = _taskManager.Tasks[deleteIndex - 1];
                            _taskManager.RemoveTask(taskToDelete.Id);
                            _activityLogger.LogTaskDeleted(taskToDelete.Title);
                            AddBotMessage($"Task deleted: '{taskToDelete.Title}'");
                        }
                        else
                        {
                            AddBotMessage("That's not a valid task number. No tasks were deleted.");
                        }
                        break;
                        
                    case "complete":
                        if (int.TryParse(input, out int completeIndex) && completeIndex > 0 && completeIndex <= _taskManager.Tasks.Count)
                        {
                            var taskToComplete = _taskManager.Tasks[completeIndex - 1];
                            _taskManager.CompleteTask(taskToComplete.Id);
                            _activityLogger.LogTaskCompleted(taskToComplete.Title);
                            AddBotMessage($"Task marked as completed: '{taskToComplete.Title}'");
                        }
                        else
                        {
                            AddBotMessage("That's not a valid task number. No tasks were marked as completed.");
                        }
                        break;
                }
                
                _isTaskMode = false;
                _currentTaskAction = "";
                UpdateTaskList();
                UpdateActivityLog();
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error processing task input: {ex.Message}");
                AddBotMessage("I couldn't process that task action. Please try again.");
                _isTaskMode = false;
                _currentTaskAction = "";
            }
        }

        private void UpdateTaskList()
        {
            try
            {
                TaskListBox.Items.Clear();
                
                foreach (var task in _taskManager.Tasks.OrderByDescending(t => t.ReminderDate.HasValue).ThenBy(t => t.IsCompleted))
                {
                    string status = task.IsCompleted ? "✓" : "□";
                    string reminder = task.ReminderDate.HasValue ? $" - {task.ReminderDate.Value.ToString("MMM dd")}" : "";
                    
                    TaskListBox.Items.Add($"{status} {task.Title}{reminder}");
                }
                
                if (TaskListBox.Items.Count == 0)
                {
                    TaskListBox.Items.Add("No security tasks yet");
                }
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error updating task list: {ex.Message}");
            }
        }

        private void StartDeleteTask()
        {
            try
            {
                if (_taskManager.Tasks.Count == 0)
                {
                    AddBotMessage("You don't have any tasks to delete.");
                    return;
                }
                
                _isTaskMode = true;
                _currentTaskAction = "delete";
                
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Which task would you like to delete? Enter the number:");
                
                for (int i = 0; i < _taskManager.Tasks.Count; i++)
                {
                    sb.AppendLine($"{i + 1}. {_taskManager.Tasks[i].Title}");
                }
                
                AddBotMessage(sb.ToString());
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error starting delete task: {ex.Message}");
                AddBotMessage("I couldn't prepare the task deletion. Please try again later.");
                _isTaskMode = false;
            }
        }

        private void StartCompleteTask()
        {
            try
            {
                var incompleteTasks = _taskManager.Tasks.Where(t => !t.IsCompleted).ToList();
                
                if (incompleteTasks.Count == 0)
                {
                    AddBotMessage("You don't have any incomplete tasks to mark as completed.");
                    return;
                }
                
                _isTaskMode = true;
                _currentTaskAction = "complete";
                
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Which task have you completed? Enter the number:");
                
                for (int i = 0; i < _taskManager.Tasks.Count; i++)
                {
                    if (!_taskManager.Tasks[i].IsCompleted)
                    {
                        sb.AppendLine($"{i + 1}. {_taskManager.Tasks[i].Title}");
                    }
                }
                
                AddBotMessage(sb.ToString());
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error starting complete task: {ex.Message}");
                AddBotMessage("I couldn't prepare the task completion. Please try again later.");
                _isTaskMode = false;
            }
        }

        private void ShowTaskList()
        {
            try
            {
                if (_taskManager.Tasks.Count == 0)
                {
                    AddBotMessage("You don't have any security tasks yet. Would you like to add one?");
                    return;
                }
                
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Here are your cybersecurity tasks:");
                
                int incompleteCount = 0;
                
                for (int i = 0; i < _taskManager.Tasks.Count; i++)
                {
                    var task = _taskManager.Tasks[i];
                    string status = task.IsCompleted ? "✓" : "□";
                    string reminder = task.ReminderDate.HasValue ? $" - Due: {task.ReminderDate.Value.ToString("MMM dd")}" : "";
                    
                    sb.AppendLine($"{status} {task.Title}{reminder}");
                    
                    if (!task.IsCompleted)
                    {
                        incompleteCount++;
                    }
                }
                
                sb.AppendLine();
                sb.AppendLine($"You have {incompleteCount} incomplete security tasks.");
                
                AddBotMessage(sb.ToString());
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error showing task list: {ex.Message}");
                AddBotMessage("I couldn't display your tasks. Please try again later.");
            }
        }

        #endregion

        #region UI Helpers

        private void AddUserMessage(string message)
        {
            try
            {
                TextBlock messageBlock = new TextBlock
                {
                    Text = message,
                    TextWrapping = TextWrapping.Wrap,
                    Margin = new Thickness(5),
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Foreground = Brushes.White,
                    Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#3498db")),
                    Padding = new Thickness(10),
                };

                Border border = new Border
                {
                    CornerRadius = new CornerRadius(10, 0, 10, 10),
                    Child = messageBlock,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Margin = new Thickness(80, 5, 10, 5)
                };

                ChatPanel.Children.Add(border);
                ScrollToBottom();
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error adding user message to UI: {ex.Message}");
            }
        }

        private void AddBotMessage(string message)
        {
            try
            {
                TextBlock messageBlock = new TextBlock
                {
                    Text = message,
                    TextWrapping = TextWrapping.Wrap,
                    Margin = new Thickness(5),
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Padding = new Thickness(10),
                };

                Border border = new Border
                {
                    CornerRadius = new CornerRadius(0, 10, 10, 10),
                    Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#f2f2f2")),
                    Child = messageBlock,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Margin = new Thickness(10, 5, 80, 5)
                };

                ChatPanel.Children.Add(border);
                ScrollToBottom();
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error adding bot message to UI: {ex.Message}");
                // Try to add a simple message as fallback
                try
                {
                    TextBlock simpleBlock = new TextBlock
                    {
                        Text = "Sorry, an error occurred displaying the message.",
                        Margin = new Thickness(10)
                    };
                    ChatPanel.Children.Add(simpleBlock);
                }
                catch
                {
                    // At this point we can't reliably display UI errors
                }
            }
        }

        private void ScrollToBottom()
        {
            try
            {
                ChatScrollViewer.UpdateLayout();
                ChatScrollViewer.ScrollToBottom();
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error scrolling chat: {ex.Message}");
            }
        }

        private void UpdateActivityLog()
        {
            try
            {
                LogListBox.Items.Clear();
                var recentLogs = _activityLogger.GetRecentLogs();
                
                foreach (var log in recentLogs)
                {
                    LogListBox.Items.Add(log);
                }
            }
            catch (Exception ex)
            {
                // We can't use the activity logger here as it might cause a recursive issue
                Console.WriteLine($"Error updating activity log: {ex.Message}");
            }
        }

        #endregion

        private void ReminderTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                var dueReminders = _taskManager.GetDueReminders();
                
                if (dueReminders.Any())
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("⏰ Security Task Reminder ⏰");
                    sb.AppendLine("The following security tasks need your attention:");
                    
                    foreach (var task in dueReminders)
                    {
                        sb.AppendLine($"• {task.Title}");
                    }
                    
                    AddBotMessage(sb.ToString());
                }
            }
            catch (Exception ex)
            {
                _activityLogger.LogError($"Error checking reminders: {ex.Message}");
            }
        }
    }
}